# 📋 Phase 3 Checkpoint — Android App Foundation
> **สถานะ:** ⏳ NOT STARTED

---

## 📋 Checkpoint Info
| Field | Value |
|---|---|
| **Phase** | Phase 3 — Android User & Admin Dashboard |
| **เริ่มวันที่** | - |
| **สถานะโดยรวม** | ⏳ NOT STARTED |

## 🎯 เป้าหมาย
สร้าง Dashboard หลักของทั้ง User Mode และ Admin Mode พร้อม Navigation

## 📌 Task List

### 👤 User Mode
| # | Task | สถานะ |
|---|---|---|
| 1.1 | UserDashboard Screen (status, notification feed) | ⏳ |
| 1.2 | UserMessages Screen (ประวัติ voice messages) | ⏳ |
| 1.3 | Audio Player Component (waveform + typewriter text) | ⏳ |
| 1.4 | Permission Status Panel (Mic/Camera/Notification) | ⏳ |
| 1.5 | Bottom Navigation (Dashboard / Messages / Profile) | ⏳ |
| 1.6 | UserViewModel + UserRepository | ⏳ |
| 1.7 | Profile Screen + Logout | ⏳ |

### 👑 Admin Mode
| # | Task | สถานะ |
|---|---|---|
| 2.1 | AdminDashboard — Real-time User List | ⏳ |
| 2.2 | User Card Component (avatar, status, last active) | ⏳ |
| 2.3 | Search/Filter bar | ⏳ |
| 2.4 | Broadcast FAB button | ⏳ |
| 2.5 | AdminControlPanel Screen (2x2 action grid) | ⏳ |
| 2.6 | Drawer Navigation | ⏳ |
| 2.7 | AdminViewModel + AdminRepository | ⏳ |

### 🎨 UI Design System
| # | Task | สถานะ |
|---|---|---|
| 3.1 | Sci-fi Color Palette + Theme | ⏳ |
| 3.2 | GlowCard Component (neon border) | ⏳ |
| 3.3 | AriaButton (angular + scan-line animation) | ⏳ |
| 3.4 | HUD Panel Component (corner brackets) | ⏳ |
| 3.5 | StatusIndicator (pulsing dot) | ⏳ |
| 3.6 | Background particle/grid effect | ⏳ |

## ➡️ เงื่อนไขก่อนไป Phase 4
- [ ] User Dashboard แสดงข้อมูลจาก API ได้
- [ ] Admin เห็น User List แบบ Real-time
- [ ] Navigation ระหว่าง Screen ทำงานถูกต้อง
- [ ] Design System ใช้งานได้ทั้งแอป

---
*Phase 3 Checkpoint — ARIA Project*
