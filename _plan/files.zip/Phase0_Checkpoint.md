# 📋 Phase 0 Checkpoint — Requirements & SRS
> **สถานะ:** 🟡 IN PROGRESS

---

## 📋 Checkpoint Info

| Field | Value |
|---|---|
| **Phase** | Phase 0 — Requirements Elicitation & SRS |
| **เริ่มวันที่** | DD/MM/YYYY |
| **อัปเดตล่าสุด** | DD/MM/YYYY |
| **สถานะโดยรวม** | 🟡 IN PROGRESS |

---

## 🎯 เป้าหมายของ Phase นี้

รวบรวม Requirement จากทุก Phase คำถาม (0–6) และสร้าง SRS Document
สมบูรณ์ก่อนเริ่มเขียน Code แม้แต่บรรทัดเดียว

---

## 📌 Task List — BA Elicitation Questions

### 🔵 Phase คำถาม 1 : Business Context
| # | คำถาม | ตอบแล้ว | คำตอบสรุป |
|---|---|---|---|
| Q1 | แอปใช้ภายในองค์กร หรือเผยแพร่สาธารณะ? | ☐ | |
| Q2 | กลุ่มผู้ใช้งานหลักคือใคร? | ☐ | |
| Q3 | จำนวน User พร้อมกันสูงสุด? | ☐ | |
| Q4 | แอปแก้ Pain Point อะไร? | ☐ | |
| Q5 | มี Competitor หรือระบบเดิมไหม? | ☐ | |
| Q6 | Timeline และ Deadline? | ☐ | |
| Q7 | งบประมาณ Infrastructure? | ☐ | |

**สถานะ Phase นี้:** ⏳ / ✅

---

### 🔵 Phase คำถาม 2 : User Roles & Permissions
| # | คำถาม | ตอบแล้ว | คำตอบสรุป |
|---|---|---|---|
| Q8 | มี Role อะไรบ้าง? | ☐ | |
| Q9 | Admin มีกี่คน? สิทธิ์ต่างกันไหม? | ☐ | |
| Q10 | User สมัครเองหรือต้อง Admin อนุมัติ? | ☐ | |
| Q11 | Admin account สร้างอย่างไร? | ☐ | |
| Q12 | Block/Suspend User ได้ไหม? | ☐ | |
| Q13 | Login หลาย Device พร้อมกันได้ไหม? | ☐ | |
| Q14 | Admin 2 คนฟัง User เดียวกันพร้อมกัน? | ☐ | |

**สถานะ Phase นี้:** ⏳ / ✅

---

### 🔵 Phase คำถาม 3A : Authentication
| # | คำถาม | ตอบแล้ว | คำตอบสรุป |
|---|---|---|---|
| Q15 | ต้องการ Social Login ไหม? | ☐ | |
| Q16 | Forgot Password — Email หรือ OTP? | ☐ | |
| Q17 | ต้องการ 2FA ไหม? | ☐ | |
| Q18 | Session timeout เท่าไหร่? | ☐ | |
| Q19 | Biometric Login ต้องการไหม? | ☐ | |

**สถานะ Phase นี้:** ⏳ / ✅

---

### 🔵 Phase คำถาม 3B : Microphone Streaming
| # | คำถาม | ตอบแล้ว | คำตอบสรุป |
|---|---|---|---|
| Q20 | User ต้อง Accept ทุกครั้ง หรือ Grant ครั้งเดียว? | ☐ | |
| Q21 | Audio — Real-time stream หรือ Record แล้วส่ง? | ☐ | |
| Q22 | บันทึกเสียงไว้ใน Server ไหม? | ☐ | |
| Q23 | Background listening ทำได้ไหม? | ☐ | |
| Q24 | แสดง indicator ว่ากำลังถูกฟังไหม? | ☐ | |

**สถานะ Phase นี้:** ⏳ / ✅

---

### 🔵 Phase คำถาม 3C : Camera Streaming
| # | คำถาม | ตอบแล้ว | คำตอบสรุป |
|---|---|---|---|
| Q25 | กล้องหน้า/หลัง หรือทั้งคู่? | ☐ | |
| Q26 | Real-time video หรือแค่ Snapshot? | ☐ | |
| Q27 | ความละเอียด Video? | ☐ | |
| Q28 | บันทึก Video ใน Server ไหม? | ☐ | |
| Q29 | User เห็นว่าถูกเปิดกล้องไหม? | ☐ | |

**สถานะ Phase นี้:** ⏳ / ✅

---

### 🔵 Phase คำถาม 3D : TTS Voice System
| # | คำถาม | ตอบแล้ว | คำตอบสรุป |
|---|---|---|---|
| Q30 | TTS Engine อยู่ Server เดียวกับ Backend ไหม? | ☐ | |
| Q31 | OS ของ TTS Server คืออะไร? | ☐ | |
| Q32 | User เลือก Voice Profile ได้ไหม? | ☐ | |
| Q33 | User ต้องกด Play เอง หรือ Auto-play? | ☐ | |
| Q34 | หลาย Message — Queue หรือรอ User กด? | ☐ | |
| Q35 | เก็บประวัติ TTS Messages กี่วัน? | ☐ | |

**สถานะ Phase นี้:** ⏳ / ✅

---

### 🔵 Phase คำถาม 3E : Notification System
| # | คำถาม | ตอบแล้ว | คำตอบสรุป |
|---|---|---|---|
| Q36 | In-App เท่านั้น หรือ Push Notification (FCM) ด้วย? | ☐ | |
| Q37 | ส่ง Notification ตอนปิดแอปได้ไหม? | ☐ | |
| Q38 | Notification Type มีอะไรบ้าง? | ☐ | |
| Q39 | ต้องการ Notification History ไหม? | ☐ | |

**สถานะ Phase นี้:** ⏳ / ✅

---

### 🔵 Phase คำถาม 4 : Technical & Infrastructure
| # | คำถาม | ตอบแล้ว | คำตอบสรุป |
|---|---|---|---|
| Q40 | Server อยู่ที่ไหน? | ☐ | |
| Q41 | OS ของ Server คืออะไร? | ☐ | |
| Q42 | Spec: RAM/CPU/Storage? | ☐ | |
| Q43 | มี Domain? ต้องการ SSL ไหม? | ☐ | |
| Q44 | ใช้ Docker ไหม? | ☐ | |
| Q45 | ต้องการ CI/CD ไหม? | ☐ | |
| Q46 | DB อยู่ Server เดียวกับ Backend ไหม? | ☐ | |
| Q47 | ต้องการ DB Backup อัตโนมัติไหม? | ☐ | |
| Q48 | ต้องการ Monitoring/Alerting ไหม? | ☐ | |

**สถานะ Phase นี้:** ⏳ / ✅

---

### 🔵 Phase คำถาม 5 : UX/UI Requirements
| # | คำถาม | ตอบแล้ว | คำตอบสรุป |
|---|---|---|---|
| Q49 | Dark Mode อย่างเดียว หรือ Light Mode ด้วย? | ☐ | |
| Q50 | ภาษา: ไทย / อังกฤษ / ทั้งคู่? | ☐ | |
| Q51 | มี Branding/Logo ไหม? | ☐ | |
| Q52 | ต้องการ Onboarding Screen ไหม? | ☐ | |
| Q53 | Android เวอร์ชันต่ำสุด? | ☐ | |
| Q54 | รองรับ Tablet ไหม? | ☐ | |
| Q55 | มี Reference UI ที่ชอบไหม? | ☐ | |

**สถานะ Phase นี้:** ⏳ / ✅

---

### 🔵 Phase คำถาม 6 : Risk & Edge Cases
| # | คำถาม | ตอบแล้ว | คำตอบสรุป |
|---|---|---|---|
| Q56 | Network หลุดระหว่าง Stream — ทำอะไร? | ☐ | |
| Q57 | TTS Server ล่ม — Fallback คืออะไร? | ☐ | |
| Q58 | ต้องการ Offline Mode ไหม? | ☐ | |
| Q59 | ต้องการ E2E Encryption ไหม? | ☐ | |
| Q60 | User ถอน Permission กลาง Session — ทำอะไร? | ☐ | |
| Q61 | มี Compliance ที่เกี่ยวข้องไหม? (PDPA?) | ☐ | |

**สถานะ Phase นี้:** ⏳ / ✅

---

## 📄 Output ที่ต้องได้จาก Phase 0

- [ ] `SRS_Document.md` — Software Requirements Specification ฉบับสมบูรณ์
- [ ] `Tech_Stack_Decision.md` — เหตุผลที่เลือก Tech Stack แต่ละอย่าง
- [ ] `System_Architecture.md` — Diagram ระบบ (Mermaid)
- [ ] `DB_ERD.md` — Entity Relationship Diagram
- [ ] `API_List.md` — รายการ API Endpoints ทั้งหมด

---

## ➡️ เงื่อนไขก่อนไป Phase 1

- [ ] ตอบครบทุกคำถาม Q1–Q61
- [ ] SRS Document สร้างเสร็จ
- [ ] User/Owner อนุมัติ SRS แล้ว
- [ ] Tech Stack ตัดสินใจสุดท้ายแล้ว

---

*Phase 0 Checkpoint — ARIA Project*
