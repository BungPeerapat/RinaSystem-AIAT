# 📋 Phase 4 Checkpoint — Real-time Streaming
> **สถานะ:** ⏳ NOT STARTED

---

## 📋 Checkpoint Info
| Field | Value |
|---|---|
| **Phase** | Phase 4 — WebSocket + Audio/Video Streaming |
| **เริ่มวันที่** | - |
| **สถานะโดยรวม** | ⏳ NOT STARTED |

## 🎯 เป้าหมาย
สร้างระบบ WebSocket สำหรับ Real-time streaming ทั้ง Audio (ฟังไมล์) และ Video (กล้อง)

## 📌 Task List

### 🔌 Backend — WebSocket Server
| # | Task | สถานะ |
|---|---|---|
| 1.1 | WebSocket Manager class (connection pool) | ⏳ |
| 1.2 | `ws://server/ws/user/{user_id}` endpoint | ⏳ |
| 1.3 | `ws://server/ws/admin/{session_id}` endpoint | ⏳ |
| 1.4 | JWT auth บน WebSocket handshake | ⏳ |
| 1.5 | Event handlers: STREAM_REQUEST, STREAM_ACCEPT, STREAM_REJECT | ⏳ |
| 1.6 | Audio chunk relay: User → Admin | ⏳ |
| 1.7 | Video frame relay: User → Admin | ⏳ |
| 1.8 | Redis Pub/Sub สำหรับ multi-instance scaling | ⏳ |
| 1.9 | Stream session บันทึกใน DB | ⏳ |

### 📱 Android — WebSocket Client
| # | Task | สถานะ |
|---|---|---|
| 2.1 | WebSocket Service (Background Foreground Service) | ⏳ |
| 2.2 | Auto-reconnect logic | ⏳ |
| 2.3 | Receive STREAM_REQUEST → แสดง Permission Dialog | ⏳ |
| 2.4 | Audio capture + ส่ง chunk ผ่าน WebSocket | ⏳ |
| 2.5 | Camera capture (CameraX) + ส่ง JPEG frames | ⏳ |
| 2.6 | "กำลังถูกฟัง" indicator บน UI | ⏳ |
| 2.7 | Admin: รับ Audio stream → แสดง Waveform | ⏳ |
| 2.8 | Admin: รับ Video stream → แสดง Camera Feed | ⏳ |
| 2.9 | Admin: Front/Back camera toggle | ⏳ |
| 2.10 | Admin: Snapshot button | ⏳ |

## ➡️ เงื่อนไขก่อนไป Phase 5
- [ ] Admin กด LISTEN → User ได้รับ request → Accept → Admin ได้ยินเสียง
- [ ] Admin กด CAMERA → User ได้รับ request → Accept → Admin เห็น video
- [ ] WebSocket reconnect ทำงานเมื่อ network หลุด

---
*Phase 4 Checkpoint — ARIA Project*

---
---

# 📋 Phase 5 Checkpoint — TTS Voice System
> **สถานะ:** ⏳ NOT STARTED

---

## 📋 Checkpoint Info
| Field | Value |
|---|---|
| **Phase** | Phase 5 — TTS Integration + Voice Message System |
| **เริ่มวันที่** | - |
| **สถานะโดยรวม** | ⏳ NOT STARTED |

## 🎯 เป้าหมาย
เชื่อม Moe-TTS (Rina-Vtuber-Voice-V2) เข้ากับ Backend และสร้างระบบส่ง Voice Message ไปหา User

## 📌 Task List

### 🔊 Backend — TTS Service
| # | Task | สถานะ |
|---|---|---|
| 1.1 | สร้าง `tts_service.py` (subprocess wrapper สำหรับ Moe-TTS) | ⏳ |
| 1.2 | ทดสอบ TTS inference โดยตรงก่อน (command line) | ⏳ |
| 1.3 | สร้าง audio storage directory + URL serving | ⏳ |
| 1.4 | `POST /api/messages/tts` endpoint | ⏳ |
| 1.5 | บันทึก message + audio_path ใน DB | ⏳ |
| 1.6 | ส่ง FCM push notification หลัง generate เสร็จ | ⏳ |
| 1.7 | ส่ง WebSocket event NEW_MESSAGE ไปหา User | ⏳ |
| 1.8 | `GET /api/messages` (ประวัติ message) | ⏳ |
| 1.9 | `PUT /api/messages/:id/read` | ⏳ |
| 1.10 | Serve audio files (static files หรือ signed URL) | ⏳ |

### 📱 Android — TTS Composer (Admin)
| # | Task | สถานะ |
|---|---|---|
| 2.1 | TTS Composer Screen (text input + sliders) | ⏳ |
| 2.2 | Speed / Pitch sliders | ⏳ |
| 2.3 | PREVIEW button → เล่นเสียงใน Admin device | ⏳ |
| 2.4 | TRANSMIT button → ส่งไปหา User | ⏳ |
| 2.5 | Loading state ระหว่าง generate | ⏳ |

### 📱 Android — Voice Message (User)
| # | Task | สถานะ |
|---|---|---|
| 3.1 | รับ FCM / WebSocket event NEW_MESSAGE | ⏳ |
| 3.2 | Download และ cache audio file | ⏳ |
| 3.3 | Auto-play หรือ Manual play (ตาม requirement) | ⏳ |
| 3.4 | Typewriter text animation ขณะเล่นเสียง | ⏳ |
| 3.5 | Audio waveform visualizer | ⏳ |
| 3.6 | Message history list | ⏳ |

### 🔔 FCM Setup
| # | Task | สถานะ |
|---|---|---|
| 4.1 | ตั้งค่า Firebase Project | ⏳ |
| 4.2 | เพิ่ม `google-services.json` ใน Android | ⏳ |
| 4.3 | ตั้งค่า Firebase Admin SDK ใน Backend | ⏳ |
| 4.4 | ทดสอบ Push Notification ถึง device | ⏳ |

## ➡️ เงื่อนไขก่อนไป Phase 6
- [ ] Admin พิมพ์ข้อความ → กด Transmit → User ได้ยินเสียง Rina
- [ ] Text แสดงบน User screen ขณะเล่นเสียง
- [ ] FCM notification ส่งได้แม้ User ปิดแอป

---
*Phase 5 Checkpoint — ARIA Project*

---
---

# 📋 Phase 6 Checkpoint — Admin Control Panel Complete
> **สถานะ:** ⏳ NOT STARTED

---

## 📋 Checkpoint Info
| Field | Value |
|---|---|
| **Phase** | Phase 6 — Admin Panel + Notification + User Management |
| **สถานะโดยรวม** | ⏳ NOT STARTED |

## 📌 Task List

### 👑 Admin Features
| # | Task | สถานะ |
|---|---|---|
| 1.1 | Notify module (Title + Body → FCM) | ⏳ |
| 1.2 | `POST /api/notify` endpoint | ⏳ |
| 1.3 | Broadcast to all users | ⏳ |
| 1.4 | User management: Block/Suspend | ⏳ |
| 1.5 | Change user role | ⏳ |
| 1.6 | View user detail screen | ⏳ |
| 1.7 | Message history per user | ⏳ |
| 1.8 | Stream history log | ⏳ |

### 📱 User Features
| # | Task | สถานะ |
|---|---|---|
| 2.1 | Notification History screen | ⏳ |
| 2.2 | Permission management screen | ⏳ |
| 2.3 | Account settings | ⏳ |

## ➡️ เงื่อนไขก่อนไป Phase 7
- [ ] Admin ทำทุก action ได้จากหน้า Control Panel
- [ ] User รับ notification ทุกประเภท
- [ ] User management ทำงานได้

---
*Phase 6 Checkpoint — ARIA Project*

---
---

# 📋 Phase 7 Checkpoint — Testing & QA
> **สถานะ:** ⏳ NOT STARTED

---

## 📌 Task List

| # | Test Case | ผล | หมายเหตุ |
|---|---|---|---|
| T1 | Register → Login → Dashboard | ⏳ | |
| T2 | Admin ฟังเสียง User (audio stream) | ⏳ | |
| T3 | Admin เปิดกล้อง User (video stream) | ⏳ | |
| T4 | Admin ส่ง TTS → User ได้ยินเสียง Rina | ⏳ | |
| T5 | Admin ส่ง Notification → User รับ | ⏳ | |
| T6 | Network หลุด → Auto reconnect | ⏳ | |
| T7 | User ปฏิเสธ stream request | ⏳ | |
| T8 | Token expired → Auto refresh | ⏳ | |
| T9 | 10 Users online พร้อมกัน (load test) | ⏳ | |
| T10 | User ถอน Permission กลาง session | ⏳ | |

---
*Phase 7 Checkpoint — ARIA Project*

---
---

# 📋 Phase 8 Checkpoint — Deployment & Launch
> **สถานะ:** ⏳ NOT STARTED

---

## 📌 Task List

| # | Task | สถานะ |
|---|---|---|
| 1 | ตั้งค่า SSL/HTTPS (Let's Encrypt) | ⏳ |
| 2 | ตั้งค่า Nginx reverse proxy | ⏳ |
| 3 | ตั้งค่า systemd / docker auto-restart | ⏳ |
| 4 | ตั้งค่า PostgreSQL backup cron job | ⏳ |
| 5 | ตั้งค่า Monitoring (uptime check) | ⏳ |
| 6 | Build Android APK (release) | ⏳ |
| 7 | ทดสอบบน VPS จริง (ไม่ใช่ localhost) | ⏳ |
| 8 | จัดทำ User Manual | ⏳ |
| 9 | จัดทำ Admin Manual | ⏳ |

## ✅ Definition of Done — โปรเจ็คเสร็จสมบูรณ์เมื่อ
- [ ] APK ติดตั้งและใช้งานได้บน Android จริง
- [ ] Backend รันบน VPS โดยไม่ crash ใน 24 ชั่วโมง
- [ ] ทุก feature ใน SRS ทำงานได้ครบ
- [ ] มี documentation สำหรับ Admin

---
*Phase 8 Checkpoint — ARIA Project*
